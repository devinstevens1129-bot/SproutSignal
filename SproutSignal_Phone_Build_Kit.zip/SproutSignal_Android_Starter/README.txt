SPROUTSIGNAL ANDROID STARTER — NOT AN APK

This is an Android Studio source project wrapping the existing v0.6 HTML prototype in an Android WebView. It is NOT a production-ready or Play-Store-ready app.

TO BUILD ON A COMPUTER:
1. Install Android Studio (free) on Windows, macOS or Linux.
2. Unzip this folder. Open the SproutSignal_Android_Starter folder in Android Studio.
3. Let Gradle sync and install Android SDK 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will report the debug APK location. Transfer it to your Android phone and install it only if you trust this source.

NOTES:
- App currently uses browser-style local storage; no cloud sync, user accounts, real push notifications, AI plant recognition, or live weather warnings.
- Download/export handling from HTML may require additional testing and native integration. Back up records before upgrading.
- Photos in the existing app are retrieved online; internet connection required.
- Android WebView's file:// local storage and cross-origin fetch behavior can vary; test all features on a physical device.
- A Play Store release requires more work, privacy disclosures, app signing, and an authorized developer account.
- This source has not been compiled or device-tested in this environment.
